agent=$1
status=$2
time=$3
test1="/etc/nginx/conf.d/apicall.sh '$agent' '$status'  '$time'"
test="/etc/nginx/conf.d/apicall.sh '"$agent"'"
echo $test



echo $agent

result=$(curl -d '{"user_agent":"'"$agent"'", "date": "'"$time"'", "response_code": "'"$status"'"}' -H 'Content-Type: application/json' http://192.168.43.96:5005/addAccessLog)
echo "Response from server"
echo $result
exit

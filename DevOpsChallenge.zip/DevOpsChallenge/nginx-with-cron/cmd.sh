#! /bin/sh
echo "hello world!!!"
crond -l 2 -f
#nginx
#nginx  -g  daemon off;

echo "not working!!!"